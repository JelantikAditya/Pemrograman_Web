document.getElementById("btn").addEventListener("click", function() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("pssw").value.trim();

    if (!name || !email || !password) {
        alert("Harap isi semua kolom sebelum mengirim!");
        return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Format email tidak valid. Contoh: nama@domain.com");
        return;
    }

    if (password.length < 8) {
        alert("Password harus memiliki minimal 8 karakter!");
        return;
    }

    alert("Form berhasil dikirim!");
});
